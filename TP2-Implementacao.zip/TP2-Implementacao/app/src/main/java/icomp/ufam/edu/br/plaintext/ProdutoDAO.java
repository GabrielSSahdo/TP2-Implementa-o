package icomp.ufam.edu.br.plaintext;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;

public class ProdutoDAO {
    private Context context;
    private SQLiteDatabase database;

    public ProdutoDAO(Context context) {
        this.context = context;
        this.database = (new Database(context)).getWritableDatabase();
    }


    public ArrayList<Produto> getList() {
        ArrayList<Produto> result = new ArrayList<Produto>();
        String sql = "SELECT * FROM produtos ORDER BY name";
        Cursor cursor = database.rawQuery(sql, null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String cdb = cursor.getString(2);
            String quantidade = cursor.getString(3);
            String notes = cursor.getString(4);
            result.add(new Produto(id, name, cdb, quantidade, notes));
        }

        return result;
    }


    public boolean add(Produto produto) {
        String sql = "INSERT INTO produtos VALUES (NULL, "
                + "'" + produto.getNome() + "', "
                + "'" + produto.getCodigoBarras() + "', "
                + "'" + produto.getQuantidade() + "', "
                + "'" + produto.getDescricao() + "')";
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Produto salvo!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }


    public boolean update(Produto produto) {
        String sql = "UPDATE produtos SET "
                + "name='" + produto.getNome() + "', "
                + "cdb='" + produto.getCodigoBarras() + "', "
                + "quantidade='" + produto.getQuantidade() + "', "
                + "notes='" + produto.getDescricao() + "' "
                + "WHERE id=" + produto.getId();
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Produto atualizado!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public boolean diminuirQuantidade(Produto produto) {
        String sql = "UPDATE produtos SET quantidade = quantidade - 1 WHERE id = " + produto.getId();
        try {
            database.execSQL(sql);
            Toast.makeText(context, "Produto Vendido!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    public boolean removerProduto(int id) {
        String sql = "DELETE FROM produtos WHERE id=" + id;

        try {
            database.execSQL(sql);
            Toast.makeText(context, "Produto Excluido!", Toast.LENGTH_SHORT).show();
            return true;
        }
        catch (SQLException e) {
            Toast.makeText(context, "Erro! " + e.getMessage(), Toast.LENGTH_SHORT).show();

        }
        return false;
    }

    public Produto get(int id) {
        String sql = "SELECT * FROM produtos WHERE id=" + id;
        Cursor cursor = database.rawQuery(sql, null);

        if (cursor.moveToNext()) {
            String name = cursor.getString(1);
            String cdb = cursor.getString(2);
            String quantidade = cursor.getString(3);
            String notes = cursor.getString(4);
            return new Produto(id, name, cdb, quantidade, notes);
        }

        return null;
    }




}
