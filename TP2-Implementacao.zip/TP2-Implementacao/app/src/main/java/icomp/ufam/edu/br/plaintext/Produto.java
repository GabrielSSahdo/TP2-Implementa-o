package icomp.ufam.edu.br.plaintext;

public class Produto {

    private int id;

    private String codigoBarras;
    private String nome;
    private String descricao;
    private String quantidade;

    public Produto(int id, String nome, String codigoBarras, String quantidade, String descricao) {
        this.id = id;
        this.nome = nome;
        this.codigoBarras = codigoBarras;
        this.descricao = descricao;
        this.quantidade = quantidade;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCodigoBarras(String codigoBarras) {
        this.codigoBarras = codigoBarras;
    }

    public String getCodigoBarras() {
        return codigoBarras;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }


    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

}
