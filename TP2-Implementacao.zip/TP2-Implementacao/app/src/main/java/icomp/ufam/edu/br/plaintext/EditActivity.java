package icomp.ufam.edu.br.plaintext;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

public class EditActivity extends AppCompatActivity {
    private Context context;
    private ProdutoDAO produtoDAO;
    private int produtoId;
    private TextView editName, editCDB, editQuantidade, editNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        editName = findViewById(R.id.addName);
        editCDB = findViewById(R.id.addCDB);
        editQuantidade = findViewById(R.id.addQuantidade);
        editNotes = findViewById(R.id.addNotes);
        produtoDAO = new ProdutoDAO(this);

        Intent intent = getIntent();
        produtoId = intent.getIntExtra("produtoId", -1);

        // Verifica se uma senha foi passada como parâmetro
        if (produtoId != -1) {
            Produto password = produtoDAO.get(produtoId);
            editName.setText(password.getNome());
            editCDB.setText(password.getCodigoBarras());
            editQuantidade.setText(password.getQuantidade());
            editNotes.setText(password.getDescricao());
        }
    }

    public void salvarClicado (View view){
        Produto produto = new Produto(produtoId, editName.getText().toString(),
                editCDB.getText().toString(), editQuantidade.getText().toString(),
                editNotes.getText().toString());

        int flag = 0;

        boolean result;
        if (produtoId == -1){
            flag = 1;
            result = produtoDAO.add(produto);
        }
        else{
            flag = 2;
            result = produtoDAO.update(produto);
        }

        Toast.makeText(context,"Flag ="+ flag, Toast.LENGTH_SHORT).show();

        if (result) finish();
    }

    public void removerClicado (View view){
        Produto produto = new Produto(produtoId, editName.getText().toString(),
                editCDB.getText().toString(), editQuantidade.getText().toString(),
                editNotes.getText().toString());

        boolean result;
        if (produtoId == -1) result = produtoDAO.update(produto);
        else result = produtoDAO.removerProduto(produto.getId());

        if (result) finish();
    }
}
